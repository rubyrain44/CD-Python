class BankAccount:
    def __init__(self, balance, interest_rate):
        self.balance = balance
        self.interest_rate = interest_rate

    def deposit(self, deposit):
        self.balance = self.balance + deposit

    def withdraw(self, withdraw):
        self.balance = self.balance - withdraw
        if self.balance < self.balance - withdraw:
            print("Insufficient funds: Charging a $5 Fee")
            self.balance = self.balance - 5

    def display_account_info(self):
        print(self.balance)

    def yield_interest_rate(self, interest_rate):
        self.balance = self.balance * (1-0.06)

rainsaccount = BankAccount(0, 0.01)
robsaccount = BankAccount(0, 0.01)

rainsaccount.deposit(14)
rainsaccount.deposit(20)
rainsaccount.deposit(50)
print(rainsaccount.balance)

rainsaccount.withdraw(45)
print(rainsaccount.balance)

rainsaccount.yield_interest_rate(0.06)
print(rainsaccount.balance)

#--------------------------

robsaccount.deposit(100)
robsaccount.deposit(200)
print(robsaccount.balance)

robsaccount.withdraw(45)
robsaccount.withdraw(45)
robsaccount.withdraw(45)
robsaccount.withdraw(45)
print(robsaccount.balance)

robsaccount.yield_interest_rate(0.09)
print(robsaccount.balance)