# for i in range(0, 151):
#     print(i)

# for i in range(5, 1001, 5):
#     print(i)

# for i in range(1, 101):
#     if i%10 == 0:
#         print("Coding Dojo")
#     elif i%5 == 0:
#         print("Coding")
#     else:
#         print(i)

#Add odd integers from 0 to 500,000, and print the final sum.
# sum=0

# for i in range(0, 500001):
#     if i%2 != 0:
#         sum+=i
# print(sum)

# for i in range(2018, 0, -4):
#     if i%2 == 0:
#         print(i)

lowNum = 2
highNum = 20
mult = 4
for i in range(lowNum, highNum, mult):
    print(i)

